# ⚡ Buildify — Site Builder com IA

Crie sites profissionais com IA em segundos, inspirado no Lovable.

---

## 🚀 Deploy no Netlify (passo a passo)

### 1. Pré-requisitos
- Conta no [Netlify](https://netlify.com) (grátis)
- Conta na [Anthropic](https://console.anthropic.com) para obter a API key
- [Node.js 18+](https://nodejs.org) instalado localmente
- [Git](https://git-scm.com) instalado

---

### 2. Subir o código no GitHub

```bash
# Na pasta buildify/
git init
git add .
git commit -m "🚀 Buildify initial commit"
git branch -M main

# Crie um repositório no GitHub e conecte:
git remote add origin https://github.com/SEU_USUARIO/buildify.git
git push -u origin main
```

---

### 3. Conectar ao Netlify

1. Acesse [app.netlify.com](https://app.netlify.com)
2. Clique em **"Add new site" → "Import an existing project"**
3. Escolha **GitHub** e selecione o repositório `buildify`
4. As configurações de build são detectadas automaticamente pelo `netlify.toml`:
   - **Build command:** `npm run build`
   - **Publish directory:** `build`
5. Clique em **"Deploy site"**

---

### 4. Adicionar a API Key da Anthropic

> ⚠️ **IMPORTANTE**: A chave NUNCA vai para o frontend. Ela fica segura na função serverless.

1. No painel do Netlify, vá em **Site settings → Environment variables**
2. Clique em **"Add a variable"**
3. Preencha:
   - **Key:** `ANTHROPIC_API_KEY`
   - **Value:** `sk-ant-...` *(sua chave da Anthropic)*
4. Clique em **Save**
5. Vá em **Deploys → Trigger deploy** para aplicar

---

### 5. Pronto! 🎉

Seu Buildify estará disponível em `https://SEU-SITE.netlify.app`

---

## 🛠️ Desenvolvimento local

```bash
npm install
npm start
# Abre em http://localhost:3000
```

Para testar a função serverless localmente:
```bash
npm install -g netlify-cli
netlify dev
```
Crie um arquivo `.env` com:
```
ANTHROPIC_API_KEY=sk-ant-...
```

---

## 📁 Estrutura do projeto

```
buildify/
├── netlify/
│   └── functions/
│       └── claude.js        ← Serverless function (API key segura aqui)
├── public/
│   └── index.html
├── src/
│   ├── index.js
│   └── App.jsx              ← Todo o app React
├── netlify.toml             ← Configuração do Netlify
└── package.json
```

---

## 🔒 Segurança

- A `ANTHROPIC_API_KEY` **nunca** é exposta no frontend
- Todas as chamadas passam pela função serverless `/api/claude`
- O iframe de preview usa `sandbox` restrito
